console.log('The app is running')

const weatherForm = document.querySelector('form')
const search= document.querySelector('input')
const messageone=document.querySelector('#message-1')
const messagetwo=document.querySelector('#message-2')

weatherForm.addEventListener('submit',(e)=>{
    e.preventDefault()

    messageone.textContent='Loading......'
    messagetwo.textContent=''
    const address= search.value
    fetch('http://localhost:3000/weather?address='+address).then((response) => {
    response.json().then((error,data)=>{
        if(error){
            console.log("error")
           messagetwo.textContent=error.error
            messageone.textContent=''
        }else{
            console.log("Data")
            messageone.textContent=data.text
            messagetwo.textContent=data.precip
        }
    })
})

})